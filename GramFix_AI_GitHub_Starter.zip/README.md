# GramFix AI — Smart Village Infrastructure Complaint Tracker

**Tagline:** One report. Faster action. Better villages.

GramFix AI is a beginner-friendly web prototype for reporting and tracking village infrastructure issues such as damaged roads, broken streetlights, blocked drainage, garbage, water-supply issues, and damaged public facilities.

## Current prototype features
- Submit a complaint with category, description, area/landmark, urgency, optional photo, and optional GPS coordinates.
- Search complaints and filter by status.
- Track statuses: Submitted → Assigned → In Progress → Resolved.
- Basic priority labels and dashboard counts.
- Optional browser speech-to-text input where supported.
- Sample demo complaints.
- Stores data in the current browser using `localStorage`.

## Important limitations
This is a **front-end demonstration**, not a live government complaint service. Data stays in the same browser/device and is not shared with officials or other users. Status changes are manual demo actions. AI image classification, user accounts, SMS notifications, cloud sync, and official panchayat integration are not implemented. Do not submit sensitive personal information.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. For GPS and some browser features, use a local development server (for example, VS Code Live Server) or HTTPS.
4. Click **Load demo data** to explore the sample workflow.

No build tools or API keys are required.

## Suggested GitHub upload
Create a public repository named `gramfix-ai`, then upload all files in this folder. In GitHub, use **Add file → Upload files** or GitHub Desktop. Copy the repository URL into the hackathon form only after you have uploaded the files.

## Project workflow
1. Resident submits issue.
2. Prototype records the location and complaint details.
3. Complaint is listed with a reference ID and status.
4. Demo user advances status to demonstrate the workflow.
5. In a future deployment, authorized officials would update status and attach proof of repair; residents could verify closure.

## Technology
- HTML, CSS, JavaScript
- Browser `localStorage`
- Geolocation API (optional)
- Web Speech API (optional, browser-dependent)

## Repository structure
- `index.html` — working prototype
- `docs/TECHNICAL_DESIGN.md` — architecture and future design
- `data/sample_complaints.json` — sample data
- `tests/TEST_CASES.md` — manual test cases
- `LICENSE` — MIT License

## UN SDG alignment
- **SDG 9:** Industry, Innovation and Infrastructure
- **SDG 11:** Sustainable Cities and Communities
- **SDG 16:** Peace, Justice and Strong Institutions
- **SDG 6:** Clean Water and Sanitation (for water/drainage reports)

## Ethical and safety notes
- Ask for permission before accessing GPS or microphone.
- Collect only the data required to fix a problem.
- In a production system, protect resident details and restrict status updates to authorized officials.
- Avoid publishing personal contact details or exact household locations on a public map.
- AI-based prioritization should assist human review, not automatically deny or ignore complaints.

## License
MIT — see `LICENSE`.
