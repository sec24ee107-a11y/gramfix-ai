# Manual Test Cases

Run `index.html` in a modern browser.

| ID | Test | Steps | Expected result |
|---|---|---|---|
| TC-01 | Required fields | Submit without category, description, or location | Browser asks user to complete required fields |
| TC-02 | Submit complaint | Fill required fields and submit | Complaint appears with a unique reference and Submitted status |
| TC-03 | Dashboard counts | Add one complaint | Total and pending counts update |
| TC-04 | Search | Search for “streetlight” | Matching streetlight complaint appears |
| TC-05 | Status filter | Select “Resolved” | Only resolved complaints appear |
| TC-06 | Status progression | Click Update status repeatedly | Status cycles through Submitted, Assigned, In Progress, Resolved |
| TC-07 | Sample data | Click Load demo data | Three sample complaints are added |
| TC-08 | GPS denied | Deny location permission | App shows a message and still allows manual landmark entry |
| TC-09 | Photo size | Select image larger than 700 KB | App rejects the image for the demo |
| TC-10 | Persistence | Submit a report and refresh page | Report remains in the same browser |
| TC-11 | Delete | Click Delete and confirm | Selected demo complaint is removed |
| TC-12 | Privacy note | Open app | User is told that data is browser-local and not sent to authorities |

## Known limitations
- Browser storage can fill up, especially with photos.
- Data is not synchronized across devices.
- This prototype does not perform server-side validation or authentication.
- Speech input depends on browser support and permissions.
