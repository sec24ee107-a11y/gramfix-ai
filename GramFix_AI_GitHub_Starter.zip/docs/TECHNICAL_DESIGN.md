# GramFix AI — Technical Design Document

## 1. Goal
Make it easier for rural residents to report local infrastructure problems and follow progress toward repair.

## 2. Users
- **Resident:** submits and searches complaints.
- **Panchayat/department staff (future role):** reviews, assigns, updates, and resolves complaints.
- **Community reviewer (future role):** confirms whether a reported repair appears complete.

## 3. Prototype architecture

```text
Resident browser
   ├── Complaint form (category, description, location, optional photo)
   ├── Optional browser GPS / speech input
   ├── Complaint tracker and filters
   └── localStorage (browser-local demo data)
```

The current prototype is intentionally front-end only. It does not send data to a server.

## 4. Proposed production architecture

```text
Resident mobile/web app
        |
        v
API gateway + authentication
        |
        v
Complaint service -------- Photo storage
        |                       |
        v                       v
Database (complaints, status history, assignments)
        |
        +---- Notification service (SMS / app)
        |
        +---- Official dashboard and analytics
        |
        +---- Optional AI classification / duplicate suggestions
```

## 5. Core complaint fields
- `id`: unique complaint reference
- `category`: road, streetlight, drainage, garbage, public facility, water, other
- `description`: resident's description
- `location`: village/area/landmark
- `gps`: optional coordinates, only with consent
- `priority`: Low, Medium, High
- `status`: Submitted, Assigned, In Progress, Resolved
- `createdAt`, `updatedAt`: timestamps
- `photo`: optional evidence
- `reporter`: optional name in prototype; production should use privacy-preserving identity handling

## 6. Status workflow
`Submitted → Assigned → In Progress → Resolved`

A production system should record who changed a status, when it changed, and why. Residents should be able to request reopening if the issue remains.

## 7. Suggested priority logic
Priority should be a recommendation for human review, based on safety risk, number of people affected, and service criticality. For example, a dangerous pothole on a busy road may be High priority. The prototype uses a user-selected priority and does not implement AI ranking.

## 8. Privacy and security
- Use HTTPS in production.
- Require role-based access for official actions.
- Validate file type and size on the server.
- Restrict photo access and avoid exposing home-level GPS coordinates publicly.
- Provide deletion and correction options.
- Keep an audit log of status changes.
- Collect only necessary personal data.

## 9. Future enhancements
1. Cloud database and secure sign-in.
2. Separate resident and official roles.
3. Tamil and other regional-language voice entry.
4. Duplicate complaint suggestions using category, time, and approximate location.
5. Image classification to suggest a category (human-confirmed).
6. Notifications by SMS or messaging service.
7. Public aggregate dashboard showing counts without exposing personal details.
8. Repair verification photo and resident feedback.

## 10. Success metrics
- Median time from submission to assignment.
- Percentage resolved within the target period.
- Percentage reopened after claimed resolution.
- Number of duplicate reports grouped.
- Resident satisfaction.
